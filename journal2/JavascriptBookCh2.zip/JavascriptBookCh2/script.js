//Looping a Triangle



// for (let triangle = 0; ;triangle++){
//     if(triangle <= 7){
//         console.log("#");
//     }
    
// }

// let triangle = 0;
// triangle = triangle + 1;

// if(triangle < 1){
//     console.log("#");
// } else if(triangle < 2){
//     console.log("##");
// } else if(triangle < 3){
//     console.log("###");
// } 

// let result = 1;
// let counter = 0;
// while (counter < 7) {
// result = console.log("#");
// counter = counter + 1;
// }
// console.log(result);

// My "solution"

console.log("#");
console.log("##");
console.log("###");
console.log("####");
console.log("#####");
console.log("######");
console.log("#######");

//Actual solution

// index = 0;
// triangle = "";
// while(index < 7){
//     console.log(triangle+="#");
//     index++;
// }

//Fizzbuzz

//print numbers 1-100
// #'s /3 = "Fizz"
// #'s /5 = "Buzz"
// #'s /3 && #'s /5 = "Fizzbuzz"
// Found out that the console.log will prioritize the first line of code and not take into account the other if statements

let n = 0;
while(n <= 100){
    console.log(n);
    n++;
    if (n % 3 === 0 && n % 5 === 0){
        console.log(n + " Fizzbuzz");
    } else if(n % 3 === 0){
        console.log(n + " Fizz");
    } else if(n % 5 === 0){
        console.log(n + " Buzz");
    } 
}

//Chessboard

//creates an 8x8 grid to form a chessboard
//binding size = 8 and make it so code can generate for any size

//could only figure out how to do the height part

let grid = 0;
while(grid < 4){
        grid++;
        console.log("# # # # ");
        console.log(" # # # #");
}


// console.log("# # # # ");
// console.log(" # # # #");
// console.log("# # # # ");
// console.log(" # # # #");
// console.log("# # # # ");
// console.log(" # # # #");

//tried to do the solution from the book but I didn't get it