let dog;
let head1, head2, head3;
let eyes1, eyes2, eyes3;
let collar1, collar2, collar3;
let bg;

let head, eyes, collar;

function preload(){
  dog = loadImage("Random.png");
  bg = loadImage("bg.jpg");

  head1 = loadImage("Random_head1.png");
  head2 = loadImage("Random_head2.png");
  head3 = loadImage("Random_head3.png");

  eyes1 = loadImage("Random_eyes1.png");
  eyes2 = loadImage("Random_eyes2.png");
  eyes3 = loadImage("Random_eyes3.png");

  collar1 = loadImage("Random_collar1.png");
  collar2 = loadImage("Random_collar2.png");
  collar3 = loadImage("Random_collar3.png");
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(69);
  image(bg, 0, 0, 400);
  image(dog, 0, 0, 400, 400);
  textSize(16);
  textFont("Comic Sans MS");
  text("Dog Accessory Shuffler!", 100, 20);
  textSize(13);
  text("Left Arrow = Hat", 10, 45);
  text("Up Arrow = Eyes", 130, 45);
  text("Right Arrow = Collars", 250, 45);

  if(head === 1){
    image(head1, 0, 0, 400, 400);
  } else if(head === 2){
    image(head2, 0, 0, 400, 400);
  } else if(head === 3){
    image(head3, 0, 0, 400, 400);
  }

  if(eyes === 1){
    image(eyes1, 0, 0, 400, 400);
  } else if (eyes === 2){
    image(eyes2, 0, 0, 400, 400);
  } else if (eyes === 3){
    image(eyes3, 0, 0, 400, 400);
  }

  if(collar === 1){
    image(collar1, 0, 0, 400, 400);
  } else if (eyes === 2){
    image(collar2, 0, 0, 400, 400);
  } else if (eyes === 3){
    image(collar3, 0, 0, 400, 400);
  }

  if(keyIsDown(LEFT_ARROW)){
    switchHat();
  }

  if(keyIsDown(UP_ARROW)){
    switchEyes();
  }

  if(keyIsDown(RIGHT_ARROW)){
    switchCollar();
  }

}

function switchHat(){
  head = int(random(1, 4));
}

function switchEyes(){
  eyes = int(random(1, 4));
}

function switchCollar(){
  collar = int(random(1, 4));
}